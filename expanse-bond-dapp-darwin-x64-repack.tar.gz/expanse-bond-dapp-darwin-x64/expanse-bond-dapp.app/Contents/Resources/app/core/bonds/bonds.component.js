(function () {
  'use strict';
  angular.
  module('bonds', []).
  component('bonds', {
    templateUrl: 'core/bonds/bonds.template.html',
    controller: function() {}
  });
})();