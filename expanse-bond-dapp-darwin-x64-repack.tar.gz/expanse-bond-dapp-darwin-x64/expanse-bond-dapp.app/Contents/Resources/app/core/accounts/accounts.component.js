(function () {
  'use strict';
  angular.
  module('accounts', []).
  component('accounts', {
      controller: function() {},
      templateUrl: 'core/accounts/accounts.template.html'
  });
})();